killbill-notification-test-plugin
==============================

Plugin to use test Killbill NotificationPluginAPI

